﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_clase05
{
    class Pluma
    {
        private string _marca;
        private int _cantidad;
        private Tinta _tinta;

        public Pluma()
        {
            this._marca = "Sin marca";
            this._cantidad = 0;
            this._tinta = null;
        }

        public Pluma(string marca) : this()
        {
            this._marca = marca;
        }

        public Pluma(string marca, int cantidad) : this(marca)
        {
            this._cantidad = cantidad;
        }

        public Pluma(string marca, int cantidad, Tinta tinta) : this(marca, cantidad)
        {
            this._tinta = tinta;
        }

        private string Mostrar()
        {
            return this._marca + " " + this._cantidad + " " + this._tinta;
        }

        public static implicit operator string Mostrar(Pluma plum)
        {
            return (Pluma)plum.Mostrar();
        }
    }
}
