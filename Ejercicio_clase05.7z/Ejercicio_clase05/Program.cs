﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_clase05
{
    class Program
    {
        static void Main(string[] args)
        {
            Tinta tin = new Tinta(ConsoleColor.Cyan, ETipoTinta.Comun);
            Tinta tin2 = new Tinta(ConsoleColor.Red, ETipoTinta.ConBrillito);
            Tinta tin3 = new Tinta(ConsoleColor.Red, ETipoTinta.ConBrillito);

            if (tin == tin2)
            {
                Console.WriteLine("Tinta 1 y Tinta 2 son iguales.\n");
            }
            else
            {
                Console.WriteLine("Tinta 1 y Tinta 2 son distintos.\n");
            }

            if (tin2 == tin3)
            {
                Console.WriteLine("Tinta 2 y Tinta 3 son iguales.\n");
            }
            else
            {
                Console.WriteLine("Tinta 2 y Tinta 3 son distintos.\n");
            }

            //Console.WriteLine(Tinta.Mostrar(tin));

            Console.ReadKey();
        }
    }
}
