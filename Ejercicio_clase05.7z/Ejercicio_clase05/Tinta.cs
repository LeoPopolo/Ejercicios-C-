﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_clase05
{
    class Tinta
    {
        private ConsoleColor _color;
        private ETipoTinta _tipo;

        public Tinta()
        {
            this._color = ConsoleColor.Blue;
            this._tipo = ETipoTinta.ConBrillito;
        }

        public Tinta(ConsoleColor c) : this()
        {
            this._color = c;
            //this._tipo = ETipoTinta.ConBrillito;
        }

        public Tinta(ConsoleColor c, ETipoTinta t) : this(c)
        {
            //this._color = c;
            this._tipo = t;
        }

        public static string Mostrar(Tinta t)
        {
            return t.Mostrar();
        }

        private string Mostrar()
        {
            string retorno = "";

            retorno += this._tipo;
            retorno += " - ";
            retorno += this._color;

            return retorno;
        }

        public static bool operator ==(Tinta t1, Tinta t2)
        {
            if (t1._color == t2._color && t1._tipo == t2._tipo)
                return true;
            else
                return false;
        }

        public static bool operator !=(Tinta t1, Tinta t2)
        {
            return !(t1 == t2);
        }
    }
}
