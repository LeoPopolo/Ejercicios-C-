﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Proyecto_Interfaces
{
    class Privado : Avion
    {
        protected int _valoracionServicioDeAbordo;

        public Privado(double precio, double velocidad, int valoracion) : base(precio, velocidad)
        {
            this._valoracionServicioDeAbordo = valoracion;
        }

        public override double VelocidadMaxima {
            get => this._velocidadMaxima;
            set => this._velocidadMaxima = value;
        }
    }
}
