﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Proyecto_Interfaces
{
    public class Familiar : Auto
    {
        protected int _cantAsientos;

        public Familiar(double precio, string patente, int cantAsientos) : base(precio, patente)
        {
            this._cantAsientos = cantAsientos;
        }

        public override string Patente
        {
            get => this._patente;
            set => this._patente = value;
        }

        public override double Precio
        {
            get
            {
                return this._precio;
            }
            set
            {
                this._precio = value;
            }
        }

    }
}
