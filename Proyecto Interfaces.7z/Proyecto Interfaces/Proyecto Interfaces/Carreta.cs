﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Proyecto_Interfaces
{
    public class Carreta : Vehiculo, IARBA
    {
        public Carreta(double precio) : base (precio)
        {

        }

        public override double Precio
        {
            get
            {
                return this._precio;
            }
            set
            {
                this._precio = value;
            }
        }

        double IARBA.CalcularImpuesto()
        {
            return this._precio * 0.18;
        }
    }
}
