﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Proyecto_Interfaces
{
    public interface IAFIP
    {
        double CalcularImpuesto();

        double PropCalcularImpuesto { get; set; }
    }
}
