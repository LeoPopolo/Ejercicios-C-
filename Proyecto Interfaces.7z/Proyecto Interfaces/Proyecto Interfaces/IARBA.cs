﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Proyecto_Interfaces
{
    public interface IARBA
    {
        double CalcularImpuesto();
    }
}
