﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Proyecto_Interfaces
{
    public class Avion : Vehiculo, IAFIP, IARBA
    {
        protected double _velocidadMaxima;

        public Avion(double precio, double velMax) : base(precio)
        {
            this._velocidadMaxima = velMax;
        }

        public override double Precio{
            get
            {
                return this._precio;
            }
            set
            {
                this._precio = value;
            }
        }

        public virtual double VelocidadMaxima {
            get
            {
                return this._velocidadMaxima;
            }
            set
            {
                this._velocidadMaxima = value;
            }
        }

        public double PropCalcularImpuesto {
            get => this._precio * 0.33;
            set => this._precio = value;
        }

        double IARBA.CalcularImpuesto()
        {
            return this._precio * 0.27;
        }

        double IAFIP.CalcularImpuesto()
        {
            return this._precio * 0.33;
        }

    }
}
