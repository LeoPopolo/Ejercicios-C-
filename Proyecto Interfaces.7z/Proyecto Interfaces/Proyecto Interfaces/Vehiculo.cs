﻿using System;

namespace Proyecto_Interfaces
{
    public abstract class Vehiculo
    {
        protected double _precio;

        public Vehiculo(double precio)
        {
            this._precio = precio;
        }

        public abstract double Precio { get; set; }

        public void MostrarPrecio()
        {
            Console.WriteLine("Precio: ", this._precio.ToString());
        }
    }
}
