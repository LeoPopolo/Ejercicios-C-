﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Proyecto_Interfaces
{
    public class Comercial : Avion, IARBA
    {
        protected int _capacidadPasajeros;

        public Comercial(double precio, double velocidad, int pasajeros) : base(precio, velocidad)
        {
            this._capacidadPasajeros = pasajeros;
        }

        public int CantidadPasajeros {
            get
            {
                return this._capacidadPasajeros;
            }
            set
            {
                this._capacidadPasajeros = value;
            }
        }

        double IARBA.CalcularImpuesto()
        {
            return this._precio * 0.25;
        }

        public override double VelocidadMaxima
        {
            get => this._velocidadMaxima;
            set => this._velocidadMaxima = value;
        }
    }
}
