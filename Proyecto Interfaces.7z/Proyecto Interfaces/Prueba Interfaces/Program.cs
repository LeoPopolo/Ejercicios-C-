﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Proyecto_Interfaces;

namespace Prueba_Interfaces
{
    public class Program
    {
        static void Main(string[] args)
        {
            Comercial f1 = new Comercial(100000, 200, 75);

            IAFIP var = f1;

            Console.WriteLine("Precio: {0}  Velocidad Maxima: {1}  Cantidad de pasajeros: {2}  Impuesto a pagar: {3}", f1.Precio, f1.VelocidadMaxima, f1.CantidadPasajeros, Gestion.MostrarImpuestoNacional(f1));

            Console.ReadKey();
        }
    }
}
