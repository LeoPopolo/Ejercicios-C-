﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_clase05
{
    class Program
    {
        static void Main(string[] args)
        {
            Tinta tin = new Tinta(ConsoleColor.Cyan, ETipoTinta.Comun);
            Tinta tin2 = new Tinta(ConsoleColor.Red, ETipoTinta.ConBrillito);
            Tinta tin3 = new Tinta(ConsoleColor.Red, ETipoTinta.ConBrillito);
            Pluma plumita = new Pluma("Bic", 10, tin3);
            Pluma plumita2 = new Pluma("Piringo", 95, tin);
            Pluma plumita3 = new Pluma("Pepito", 85, tin);

            /*Console.WriteLine(plumita + tin3);
            Console.WriteLine(plumita2 + tin);
            Console.WriteLine(plumita3 + tin3);*/
            Console.WriteLine(plumita3 - tin3);
            Console.WriteLine(plumita - tin);
            Console.WriteLine(plumita2 - tin);

            /*if (plumita == tin2)
            {
                Console.WriteLine("la pluma tiene la tinta de tin2.\n");
            }
            else
            {
                Console.WriteLine("la pluma no tiene la tinta de tin2.\n");
            }

            if (plumita == tin)
            {
                Console.WriteLine("la pluma tiene la tinta de tin1.\n");
            }
            else
            {
                Console.WriteLine("la pluma no tiene la tinta de tin1.\n");
            }*/

            /*if (tin == tin2)
            {
                Console.WriteLine("Tinta 1 y Tinta 2 son iguales.\n");
            }
            else
            {
                Console.WriteLine("Tinta 1 y Tinta 2 son distintos.\n");
            }

            

            if (tin2 == tin3)
            {
                Console.WriteLine("Tinta 2 y Tinta 3 son iguales.\n");
            }
            else
            {
                Console.WriteLine("Tinta 2 y Tinta 3 son distintos.\n");
            }*/

            //Console.WriteLine(Tinta.Mostrar(tin));

            Console.ReadKey();
        }
    }
}
