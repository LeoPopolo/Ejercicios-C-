using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidad
{
    public class Sello
    {
        public static string mensaje;
        public static ConsoleColor color;

        public static string Imprimir()
        {
            string formato;
            if(Sello.TryParse(Sello.mensaje, out formato))
            {
               formato = ArmarFormatoMensaje();
            }
            else
            {
              Console.ForegroundColor = ConsoleColor.Red;
              formato = "Su mensaje esta vacio.\n";
            }
            
            return formato; 
        }

        public static void Borrar()
        {
            Sello.mensaje = "";
        }

        public static void ImprimirEnColor()
        {
            Console.ForegroundColor = Sello.color;
            Console.WriteLine(Sello.Imprimir());
            Console.ForegroundColor = ConsoleColor.White;
        }

        private static string ArmarFormatoMensaje()
        {
            string variable = "";
          
            for(int i=1; i<=mensaje.Length + 2; i++)
            {
                variable += "*";
            }
            variable += "\n";

            variable += "*" + mensaje + "*\n";

            for (int i = 1; i <= mensaje.Length + 2; i++)
            {
                variable += "*";
            }

             return variable;
        }

        private static bool TryParse(string mens, out string mens2)
        {
            bool a;
            mens2 = "";

            if(mens.Length > 0)
            {
                a = true;
            }
            else
            {
                a = false;
            }

            return a;
        }
    }
}
