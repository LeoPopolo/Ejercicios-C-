﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_08
{
    class Program
    {
        static void Main(string[] args)
        {
            int valorHs;
            string nombre;
            int anios;
            int hsTotales;
            int importe;

            Console.Write("ingrese el valor por hora: ");
            valorHs = Convert.ToInt32(Console.ReadLine());
            Console.Write("ingrese el nombre del empleado: ");
            nombre = Console.ReadLine();
            Console.Write("ingrese la antiguedad (en años): ");
            anios = Convert.ToInt32(Console.ReadLine());
            Console.Write("ingrese las horas trabajadas en el mes: ");
            hsTotales = Convert.ToInt32(Console.ReadLine());

            importe = ((hsTotales * valorHs) + (anios * 150)) ;
            importe = importe - (importe * 13 / 100);

            Console.Clear();
            Console.WriteLine("Nombre: {0}", nombre);
            Console.WriteLine("Antiguedad: {0} años", anios);
            Console.WriteLine("Valor por hora: ${0}", valorHs);
            Console.WriteLine("Total a cobrar: ${0}", importe);
            Console.ReadKey(true);
        }
    }
}
