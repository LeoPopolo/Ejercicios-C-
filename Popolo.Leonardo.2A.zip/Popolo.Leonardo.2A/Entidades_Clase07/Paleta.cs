using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades.Clase07
{
  public class Paleta
  {
    private Tempera[] _colores;
    private int _cantMaximaElementos;

    public Tempera this[int indice]
    {
      get {
        if (indice >= 0 && indice < this._colores.GetLength(0))
          return this._colores[indice];
        else
          return null;
      }

      set {
        if (indice >= 0 && indice < this._colores.GetLength(0))
        {
          this._colores[indice] = value;
        }
      }
    }

    private Paleta() : this(5)
    {

    }

    public Paleta(int cant)
    {
      this._cantMaximaElementos = cant;
      this._colores = new Tempera[this._cantMaximaElementos];
    }

    private string Mostrar()
    {
      string retorno = "";

      foreach (Tempera temp in this._colores)
      {
        retorno += temp;
      }

      return retorno;
    }

    public static explicit operator string(Paleta pal)
    {
      string var = "";

      if (pal != null)
        var = pal.Mostrar();
      return var;
    }

    public static implicit operator Paleta(int num)
    {
      return new Paleta(num);
    }

    public static bool operator ==(Paleta pal, Tempera tem)
    {
      bool retorno = false;

      for (int i = 0; i < pal._cantMaximaElementos; i++)
      {
        if (pal._colores.GetValue(i) != null)
        {
          if (pal._colores[i] == tem)
          {
            retorno = true;
            break;
          }
        }
      }

      return retorno;
    }

    public static bool operator !=(Paleta pal, Tempera tem)
    {
      return !(pal == tem);
    }

    public static Paleta operator +(Paleta pal, Tempera tem)
    {
      int index = 0;
      int index2 = 0;

      index = pal.ObtenerIndice();
      index2 = pal.ObtenerIndice(tem);

      if (pal == tem)
      {
        if (index2 >= 0)
          pal._colores[index2] += tem;
      }
      else
      {
        if (index > -1)
          pal._colores[index] = tem;
      }

      return pal;
    }

    public static Paleta operator -(Paleta pal, Tempera tem)
    {
      int index = 0;
      sbyte a;
      sbyte b;

      index = pal.ObtenerIndice(tem);

      a = (sbyte)pal._colores[index];
      b = (sbyte)tem;

      if (pal == tem)
      {
        if (index >= 0)
        {
          if (a - b <= 0)
            pal._colores[index] = null;
          else
            pal._colores[index] += (sbyte)(b * (-1));
        }
      }

      return pal;
    }

    private int ObtenerIndice()
    {
      for (int i = 0; i < this._cantMaximaElementos; i++)
      {
        if ((object)this._colores[i] == null)
        {
          return i;
        }
      }

      return -1;
    }

    private int ObtenerIndice(Tempera t)
    {
      for (int i = 0; i < this._cantMaximaElementos; i++)
      {
        if ((object)this._colores.GetValue(i) != null)
        {
          if (this._colores[i] == t)
          {
            return i;
          }
        }
      }

      return -1;
    }
  }
}
