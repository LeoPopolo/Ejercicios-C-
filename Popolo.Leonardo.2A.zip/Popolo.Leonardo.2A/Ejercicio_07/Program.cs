using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_07
{
    class Program
    {
        static void Main(string[] args)
        {
            DateTime fecha = new DateTime();
            DateTime fecha1 = new DateTime();
            fecha1 = DateTime.Now;

            Console.Write("Ingrese fecha de nacimiento (dd/mm/aaaa): ");
            fecha = Convert.ToDateTime(Console.ReadLine());
            Console.WriteLine("Usted vivio {0} dias", fecha1.Subtract(fecha).Days);
            Console.ReadKey();
        }
    }
}
