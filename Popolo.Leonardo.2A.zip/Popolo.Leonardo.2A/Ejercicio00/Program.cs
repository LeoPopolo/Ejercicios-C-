﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio00
{
    class Ejercicio00
    {
        static void Main(string[] args)
        {
            string nombre;
            sbyte edad;
            
            Console.Write("Ingrese su nombre: ");
            nombre = Console.ReadLine();
            Console.Write("Ingrese su edad: ");
            edad = sbyte.Parse(Console.ReadLine());
            Console.Write("su nombre es {0} y tiene {1} años", nombre, edad);
            Console.ReadKey();
        }
    }
}
