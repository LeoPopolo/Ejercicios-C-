﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_Clase04
{
    class Program
    {
        static void Main(string[] args)
        {
            Cosa miCosa = new Cosa();
            Cosa miCosa2 = new Cosa();
            Cosa miCosa3 = new Cosa("Roman");

            miCosa.EstablecerValor("Juan", 40896935, DateTime.Now);

            Console.WriteLine(Cosa.Mostrar(miCosa));
            Console.WriteLine(Cosa.Mostrar(miCosa2));
            Console.WriteLine(Cosa.Mostrar(miCosa3));

            Console.ReadKey();
        }
    }
}
