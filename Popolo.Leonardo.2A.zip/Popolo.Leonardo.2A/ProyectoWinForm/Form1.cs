using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades.Clase07;

namespace ProyectoWinForm
{
  public partial class Form1 : Form
  {
    Paleta _miPaleta;

    public Form1()
    {
      InitializeComponent();

      this._miPaleta = 5;

      this.groupBox1.Text = "Paleta de colores";
      this.textBox1.Multiline = true;
      this.button1.Text = "+";
      this.button2.Text = "-";

    }

    private void Form1_Load(object sender, EventArgs e)
    {

    }

    private void agregarPaletaToolStripMenuItem_Click_1(object sender, EventArgs e)
    {
      this.groupBox1.Visible = true;
      this.menuStrip1.Visible = false;
    }

    private void button1_Click(object sender, EventArgs e)
    {
      frmTempera f = new frmTempera();
      f.StartPosition = FormStartPosition.CenterScreen;

      DialogResult rta = f.ShowDialog();

      if (rta == DialogResult.OK)
      {
        this._miPaleta += f.MiTempera;
        this.textBox1.Text = (string)this._miPaleta;
      }
    }

    private void button2_Click(object sender, EventArgs e)
    {
      string texto = textBox1.SelectedText;
      int index = -1;

      foreach (string item in textBox1.Lines)
      {
        if (texto == item)
        {
          break;
        }
        index++;
      }

      this._miPaleta[index]; // asignar a un objeto tempera

    }
  }
}
