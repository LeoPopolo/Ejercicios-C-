﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Geometria
{
    class Punto
    {
        private int x;
        private int y;

        public Punto()
        {
 
        }

        public Punto(int x, int y)
        {
            this.x = x;
            this.y = y;
        }

        public int GetX()
        {
            return this.x;

        }
        public int GetY()
        {
            return this.y;
        }
    }

    class Rectangulo
    {
        float b;
        float lado;
        float area;
        float perimetro;
        Punto vertice1;
        Punto vertice2;
        Punto vertice3;
        Punto vertice4;

        public Rectangulo()
        {
 
        }

        public Rectangulo(Punto vertice1, Punto vertice3)
        {
            this.vertice1 = vertice1;
            this.vertice3 = vertice3;
            this.vertice2 = new Punto(this.vertice3.GetX(), this.vertice1.GetY());
            this.vertice4 = new Punto(this.vertice1.GetX(), this.vertice3.GetY());
            this.lado = Math.Abs(this.vertice1.GetX() - this.vertice2.GetX());
            this.b = Math.Abs(this.vertice4.GetY() - this.vertice1.GetY());
            this.perimetro = this.lado * 2 + this.b * 2;
            this.area = this.lado * this.b;
        }

        public float Area()
        {
            return this.area;
        }

        public float Perimetro()
        {
            return this.perimetro;
        }

        public float Lado()
        {
            return this.lado;
        }

        public float B()
        {
            return this.b;
        }
    }
}
