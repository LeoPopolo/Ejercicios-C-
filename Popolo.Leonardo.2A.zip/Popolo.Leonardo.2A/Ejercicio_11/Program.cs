﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_11
{
    class Program
    {
        static void Main(string[] args)
        {
            int num;
            bool val;
            int max = 0;
            int min = 0;
            int acum = 0;
            float promedio;

            for (int i = 0; i < 10; i++)
            {
                do
                {
                    Console.Write("{0}-Ingrese un numero: ", i+1);
                    num = int.Parse(Console.ReadLine());
                    val = Validacion.Validar(num, -100, 100);
                    acum = acum + num;
                    if (i == 0 && val)
                    {
                        max = num;
                        min = num;
                    }
                    if (num > max && val)
                    {
                        max = num;
                    }
                    if (num < min && val)
                    {
                        min = num;
                    }
                }while(val == false);
            }    
            promedio = (float)(acum / 5.0);

            Console.WriteLine("\nEl numero mas grande es: {0}\nel numero mas chico es: {1}\nel promedio de todos los numeros es: {2}", max, min, promedio);
            Console.ReadKey();
        }
    }
}
