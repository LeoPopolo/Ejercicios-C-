﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_09
{
    class Program
    {
        static void Main(string[] args)
        {
            int altura;

            Console.Write("ingrese altura de la piramide: ");
            altura = int.Parse(Console.ReadLine());
            Console.Clear();

            for (int i = 1; i <= altura; i++)
            {
                for (int j = 0; j < (i * 2) - 1; j++)
                {
                    Console.Write("*");
                }
                Console.Write("\n");
            }

            Console.ReadKey();
        }
    }
}
