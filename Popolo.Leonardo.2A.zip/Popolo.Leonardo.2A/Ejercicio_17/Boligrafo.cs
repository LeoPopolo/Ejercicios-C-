﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_17
{
    class Boligrafo
    {
        const short cantidadTintaMaxima = 100;
        short tinta;
        public ConsoleColor color;

        public Boligrafo()
        {
            
        }

        public Boligrafo(ConsoleColor color)
        {
            this.color = color;
        }

        public Boligrafo(ConsoleColor color, short tinta)
        {
            this.color = color;
            this.SetTinta(tinta);
        }

        public ConsoleColor GetColor()
        {
            return this.color;
        }

        public short GetTinta()
        {
            return this.tinta;
        }

        public bool Pintar(short gasto, out string dibujo)
        {
            int i;
            bool retorno = false;
            dibujo = "";
            if (this.GetTinta() - gasto >= 0)
            {
                this.tinta -= gasto;
                for (i = 0; i < gasto; i++)
                {
                    dibujo += "*";
                    retorno = true;
                }
            }
            else
            {
                dibujo = "No hay tinta suficiente!!";
                retorno = false;
            }

            if (this.GetTinta() <= 0)
            {
                this.Recargar();
            }
            return retorno;
        }

        public void Recargar()
        {
            Console.WriteLine("Tinta agotada, se recargara.");
            this.tinta = cantidadTintaMaxima;
        }

        private void SetTinta(short tinta)
        {
            if(tinta > 0 && (this.tinta + tinta) <= cantidadTintaMaxima)
            this.tinta += tinta;
        }
    }
}
