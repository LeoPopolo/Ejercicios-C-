﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_13
{
    class Program
    {
        static void Main(string[] args)
        {
            sbyte opcion;
            int decimalN;
            string binario;

            do{
                Console.Clear();
                Console.Write("1-Convertir numero decimal a binario\n2-Convertir numero binario a decimal\n3-Salir\n\nIngrese opcion: ");
                opcion = Convert.ToSByte(Console.ReadLine());
                Console.Clear();
                switch (opcion)
                {
                
                    case 1: 
                        Console.Write("Ingrese numero decimal positivo: ");
                        decimalN = Convert.ToInt32(Console.ReadLine());
                        Console.Write("\nEl numero {0} en binario es {1}.", decimalN, Conversor.DecimalABinario(decimalN));
                        Console.ReadKey(true);
                        break;
                    case 2:
                        Console.Write("Ingrese numero binario: ");
                        binario = Console.ReadLine();
                        Console.Write("\nEl numero {0} en decimal es {1}.", binario, Conversor.BinarioADecimal(binario));
                        Console.ReadKey(true);
                        break;
                    case 3:
                        Console.WriteLine("Adios.");
                        break;
                    default:
                        Console.WriteLine("Opcion incorrecta.");
                        Console.ReadKey(true);
                        break;
                }
            }while(opcion != 3);
            
        }
    }
}
