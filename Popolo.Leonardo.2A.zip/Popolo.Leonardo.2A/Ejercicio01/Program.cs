﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio01
{
    class Ejerciçio01
    {
        static void Main(string[] args)
        {
            int num;
            int max = 0;
            int min = 0;            
            int acum = 0;
            float promedio;
            
            
            for(int i=0; i<5; i++)
            {
                Console.Write("Ingrese un numero: ");
                num = Convert.ToInt32(Console.ReadLine());
                acum = acum + num;
                if(i == 0)
                {
                    max = num;
                    min = num;
                }
                if (num > max)
                {
                    max = num;
                }
                if (num < min)
                {
                    min = num;
                }
            }

            promedio = (float)(acum / 5.0);

            Console.WriteLine("el numero mas grande es: {0}\nel numero mas chico es: {1}\nel promedio de todos los numeros es: {2}", max, min, promedio);
            Console.ReadKey();
        }
    }
}
