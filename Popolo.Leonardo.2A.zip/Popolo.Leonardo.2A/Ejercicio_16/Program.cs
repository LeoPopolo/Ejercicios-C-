﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_16
{
    class Program
    {
        static void Main(string[] args)
        {
            byte nota1;
            byte nota2;
            Alumno alumnoUno = new Alumno("Juan","Perez", 1234);
            Alumno alumnoDos = new Alumno("Lucas", "Garcia", 2345);
            Alumno alumnoTres = new Alumno("Sofia", "Lopez", 3456);

            Console.WriteLine("\n" + alumnoUno.nombre + alumnoUno.apellido);
            Console.Write("Ingrese la nota 1 del alumno: ");
            nota1 = byte.Parse(Console.ReadLine());
            Console.Write("Ingrese la nota 2 del alumno: ");
            nota2 = byte.Parse(Console.ReadLine());          
            alumnoUno.Estudiar(nota1, nota2);
            Console.WriteLine("\n" + alumnoDos.nombre + alumnoDos.apellido);
            Console.Write("Ingrese la nota 1 del alumno: ");
            nota1 = byte.Parse(Console.ReadLine());
            Console.Write("Ingrese la nota 2 del alumno: ");
            nota2 = byte.Parse(Console.ReadLine());
            alumnoDos.Estudiar(nota1, nota2);
            Console.WriteLine("\n" + alumnoTres.nombre + alumnoTres.apellido);
            Console.Write("Ingrese la nota 1 del alumno: ");
            nota1 = byte.Parse(Console.ReadLine());
            Console.Write("Ingrese la nota 2 del alumno: ");
            nota2 = byte.Parse(Console.ReadLine());
            alumnoTres.Estudiar(nota1, nota2);

            alumnoUno.CalcularFinal();
            alumnoDos.CalcularFinal();
            alumnoTres.CalcularFinal();

            Console.Clear();
            alumnoUno.Mostrar();
            alumnoDos.Mostrar();
            alumnoTres.Mostrar();

            Console.ReadKey();

        }
    }
}
