﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades
{
    public class Camion : Vehiculo
    {
       protected float _tara;

        public Camion(string patente, EMarcas marca, byte cantR, int tara) : base(patente, 6, marca)
        {
            this._tara = tara;
        }

        public Camion(Vehiculo v, int tara) : this(v.Patente, v.Marca, v.CantRuedas, tara)
        {
            
        }

        protected override string Mostrar()
        {
            return base.Mostrar() + this._tara.ToString();
        }

        public override string ToString()
        {
            return this.Mostrar();
        }
    }
}
