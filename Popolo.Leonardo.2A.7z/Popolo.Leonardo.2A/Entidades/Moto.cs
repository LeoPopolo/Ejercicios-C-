﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades
{
    public class Moto : Vehiculo
    {
        protected float _cilindrada;

        public Moto(EMarcas marca, float cilindrada, string patente, byte cantRuedas) : base(patente, cantRuedas, marca)
        {
            this._marca = marca;
        }

        protected override string Mostrar()
        {
            return base.Mostrar() + this._cilindrada.ToString();
        }

        public override string ToString()
        {
            return this.Mostrar();
        }
    }
}
