﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades
{
    class Lavadero
    {
        private List<Vehiculo> _vehiculos;
        private static float _precioAuto;
        private static float _precioCamion;
        private static float _precioMoto;
        private string _razonSocial;

        public string LavaderoToString {
            get
            {
                StringBuilder sb = new StringBuilder();

                sb.AppendFormat("Razon social: {0}\r\nprecio auto: {1}\r\nprecio camion: {2}\r\nprecio moto: {3}\r\n", this._razonSocial, _precioAuto, _precioCamion, _precioMoto);
                foreach (Vehiculo v in this._vehiculos)
                {
                    sb.AppendLine(v.ToString());
                }

                return sb.ToString();
            }
        }

        public List<Vehiculo> Vehiculos
        {
            get
            {
                return this._vehiculos;
            }
        }

        private Lavadero()
        {
            this._vehiculos = new List<Vehiculo>();
        }

        public Lavadero(string rs) : this()
        {
            this._razonSocial = rs;
        }

        static Lavadero()
        {
            Random rnd = new Random();

            _precioAuto = rnd.Next(150, 566);
            _precioMoto = rnd.Next(150, 566);
            _precioCamion = rnd.Next(150, 566);
        }

        public double MostrarTotalFacturado()
        { 
            return this.MostrarTotalFacturado(EVehiculos.Auto) + this.MostrarTotalFacturado(EVehiculos.Camion) + this.MostrarTotalFacturado(EVehiculos.Moto);
        }

        public double MostrarTotalFacturado(EVehiculos en)
        {
            double fact = 0;
            int contMotos = 0;
            int contAutos = 0;
            int contCamion = 0;

            foreach (Vehiculo v in this._vehiculos)
            {
                if (v is Auto) contAutos++;
                if (v is Moto) contMotos++;
                if (v is Camion) contCamion++;
            }

            switch (en)
            {
                case EVehiculos.Auto:
                    fact = contAutos * _precioAuto;
                    break;
                case EVehiculos.Camion:
                    fact = contCamion * _precioCamion;
                    break;
                case EVehiculos.Moto:
                    fact = contMotos * _precioMoto;
                    break;
                default:
                    break;
            }

            return fact;
        }

        public static bool operator ==(Lavadero l1, Vehiculo v1)
        {
            foreach (Vehiculo v in l1.Vehiculos)
            {
                if (v == v1)
                {
                    return true;
                }
            }

            return false;
        }

        public static bool operator !=(Lavadero l1, Vehiculo v1)
        {
            return !(l1 == v1);
        }

        public static int operator ==(Vehiculo v1, Lavadero l1)
        {
            int retorno = -1;

            foreach (Vehiculo v in l1.Vehiculos)
            {
                if (v == v1)
                {
                    retorno = l1._vehiculos.IndexOf(v);
                }
            }

            return retorno;
        }

        public static int operator !=(Vehiculo v1, Lavadero l1)
        {
            return (v1 == l1) * -1;
        }

        public static Lavadero operator +(Lavadero l1, Vehiculo v1)
        {
            if (l1 != v1)
            {
                l1._vehiculos.Add(v1);
            }

            return l1;

        }

        public static Lavadero operator -(Lavadero l1, Vehiculo v1)
        {
            if (l1 == v1)
            {
                l1._vehiculos.Remove(v1);
            }

            return l1;
        }

        public static int OrdenarVehiculosPorPatente(Vehiculo v1, Vehiculo v2)
        {
            int retorno;

            if (v1.Patente == v2.Patente)
                retorno = 0;
            else if (v1.Patente.CompareTo(v2.Patente) > 0)
                retorno = 1;
            else
                retorno = -1;

            return retorno;
        }

        public static int OrdenarVehiculosPorMarca(Vehiculo v1, Vehiculo v2)
        {
            int retorno;

            if (v1.Marca == v2.Marca)
                retorno = 0;
            else if (v1.Marca.CompareTo(v2.Marca) > 0)
                retorno = 1;
            else
                retorno = -1;

            return retorno;
        }
    }
}
