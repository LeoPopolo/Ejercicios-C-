﻿using System;

namespace Entidades
{
    public class Vehiculo
    {
        protected string _patente;
        protected byte _cantRuedas;
        protected EMarcas _marca;

        public string Patente
        {
            get
            {
                return this._patente;
            }
        }

        public EMarcas Marca
        {
            get
            {
                return this._marca;
            }
        }

        public byte CantRuedas
        {
            get
            {
                return this._cantRuedas;
            }

            set
            {
                this._cantRuedas = value;
            }
        }

        protected virtual string Mostrar()
        {
            return this.Marca.ToString() + this.Patente + this.CantRuedas.ToString();
        }

        public override string ToString()
        {
            return this.Mostrar();
        }

        public Vehiculo(string patente, byte cantRuedas, EMarcas marca)
        {
            this.CantRuedas = cantRuedas;
            this._marca = marca;
            this._patente = patente;
        }

        public static bool operator ==(Vehiculo v1, Vehiculo v2)
        {
            if (v1.Patente == v2.Patente && v1.Marca == v2.Marca)
                return true;
            else
                return false;
        }

        public static bool operator !=(Vehiculo v1, Vehiculo v2)
        {
            return !(v1 == v2);
        }
    }
}
