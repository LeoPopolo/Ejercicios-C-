﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades
{
    public class Auto : Vehiculo
    {
        protected int _cantidadAsientos;

        public Auto(string patente, EMarcas marca, int cantAsientos, byte cantR) : base(patente, cantR, marca)
        {
            this._cantidadAsientos = cantAsientos;
        }

        public Auto(string patente, EMarcas marca, int cantAsientos) : this(patente, marca, cantAsientos, 4)
        {
            
        }

        protected override string Mostrar()
        {
            return base.Mostrar() + this._cantidadAsientos.ToString();
        }

        public override string ToString()
        {
            return this.Mostrar();
        }
    }
}
